import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { readFileSync, writeFileSync, existsSync } from "fs";
import fetch from "node-fetch";
import { Client, GatewayIntentBits } from "discord.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

/* ============================================================
   Config store — flat JSON file, single-user personal project.
   Holds per-service app credentials, refresh tokens, and the
   manual status. The setup wizard reads/writes this directly,
   so nothing here requires hand-editing a .env file or a
   server restart to take effect.
   ============================================================ */

const CONFIG_PATH = path.join(__dirname, "config.json");

function loadConfig() {
  if (!existsSync(CONFIG_PATH)) return {};
  try {
    return JSON.parse(readFileSync(CONFIG_PATH, "utf-8"));
  } catch {
    return {};
  }
}
function saveConfig(data) {
  writeFileSync(CONFIG_PATH, JSON.stringify(data, null, 2), "utf-8");
}
function getService(name) {
  return loadConfig()[name] || {};
}
function setService(name, patch) {
  const data = loadConfig();
  data[name] = { ...(data[name] || {}), ...patch };
  saveConfig(data);
  return data[name];
}

/* ============================================================
   Spotify — OAuth + now-playing polling. Reads clientId/Secret
   from config.json at call time so the wizard's save takes
   effect immediately.
   ============================================================ */

const spotify = {
  scopes: "user-read-currently-playing user-read-playback-state",

  authHeader(cfg) {
    return "Basic " + Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString("base64");
  },

  buildAuthUrl(redirectUri) {
    const cfg = getService("spotify");
    const params = new URLSearchParams({
      client_id: cfg.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: this.scopes,
    });
    return `https://accounts.spotify.com/authorize?${params}`;
  },

  async exchangeCode(code, redirectUri) {
    const cfg = getService("spotify");
    const res = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: this.authHeader(cfg),
      },
      body: new URLSearchParams({ grant_type: "authorization_code", code, redirect_uri: redirectUri }),
    });
    const data = await res.json();
    if (data.refresh_token) setService("spotify", { refreshToken: data.refresh_token });
    return data;
  },

  async getAccessToken() {
    const cfg = getService("spotify");
    if (!cfg.refreshToken) return null;
    const res = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: this.authHeader(cfg),
      },
      body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: cfg.refreshToken }),
    });
    const data = await res.json();
    return data.access_token || null;
  },

  async getNowPlaying() {
    const token = await this.getAccessToken();
    if (!token) return { connected: false };

    const res = await fetch("https://api.spotify.com/v1/me/player/currently-playing", {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.status === 204 || res.status === 404) return { connected: true, playing: false };
    if (!res.ok) return { connected: true, playing: false, error: `Spotify API ${res.status}` };

    const data = await res.json();
    if (!data?.item) return { connected: true, playing: false };

    return {
      connected: true,
      playing: data.is_playing,
      track: data.item.name,
      artist: data.item.artists.map((a) => a.name).join(", "),
      album: data.item.album.name,
      cover: data.item.album.images?.[0]?.url || null,
      durationMs: data.item.duration_ms,
      progressMs: data.progress_ms,
    };
  },
};

/* ============================================================
   Lyrics — lrclib.net: free, open, purpose-built for synced
   lyrics. No key, no scraping, no ToS issue.
   ============================================================ */

const lyricsCache = new Map();

function parseLrc(lrc) {
  if (!lrc) return null;
  const lines = [];
  for (const raw of lrc.split("\n")) {
    const match = raw.match(/\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\](.*)/);
    if (!match) continue;
    const [, mm, ss, ms = "0", text] = match;
    const timeMs = parseInt(mm) * 60000 + parseInt(ss) * 1000 + parseInt(ms.padEnd(3, "0"));
    if (text.trim()) lines.push({ timeMs, text: text.trim() });
  }
  return lines.length ? lines.sort((a, b) => a.timeMs - b.timeMs) : null;
}

async function getLyrics({ track, artist, album, durationMs }) {
  if (!track || !artist) return null;
  const key = `${artist}::${track}`;
  if (lyricsCache.has(key)) return lyricsCache.get(key);

  const params = new URLSearchParams({ track_name: track, artist_name: artist });
  if (album) params.set("album_name", album);
  if (durationMs) params.set("duration", String(Math.round(durationMs / 1000)));

  try {
    const res = await fetch(`https://lrclib.net/api/get?${params}`, {
      headers: { "User-Agent": "personal-dashboard/1.0" },
    });
    if (!res.ok) {
      lyricsCache.set(key, null);
      return null;
    }
    const data = await res.json();
    const result = { synced: parseLrc(data.syncedLyrics), plain: data.plainLyrics || null };
    lyricsCache.set(key, result);
    return result;
  } catch {
    return null;
  }
}

/* ============================================================
   Discord — reads YOUR OWN presence via a normal bot sitting in
   a private server you control. Not a self-bot/user-token hack
   (that's against Discord's ToS and risks account termination).
   Reconnects automatically whenever the wizard saves new creds.
   ============================================================ */

let discordClient = null;
let discordLatest = { connected: false };

function startDiscordBot() {
  const cfg = getService("discord");
  if (!cfg.botToken || !cfg.userId || !cfg.guildId) {
    discordLatest = { connected: false };
    return;
  }

  if (discordClient) {
    discordClient.destroy();
    discordClient = null;
  }

  discordClient = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildPresences, GatewayIntentBits.GuildMembers],
  });

  function snapshot(presence) {
    if (!presence) {
      discordLatest = { connected: true, status: "offline", activities: [] };
      return;
    }
    discordLatest = {
      connected: true,
      status: presence.status,
      activities: presence.activities.map((a) => ({
        name: a.name,
        type: a.type,
        details: a.details || null,
        state: a.state || null,
      })),
    };
  }

  discordClient.once("ready", async () => {
    console.log(`[discord] Bot logged in as ${discordClient.user.tag}`);
    try {
      const guild = await discordClient.guilds.fetch(cfg.guildId);
      const member = await guild.members.fetch({ user: cfg.userId, withPresences: true });
      snapshot(member.presence);
    } catch (err) {
      discordLatest = { connected: false, error: err.message };
    }
  });

  discordClient.on("presenceUpdate", (_old, presence) => {
    if (presence.userId === cfg.userId && presence.guild.id === cfg.guildId) snapshot(presence);
  });

  discordClient.login(cfg.botToken).catch((err) => {
    discordLatest = { connected: false, error: err.message };
    console.error("[discord] Login failed:", err.message);
  });
}

/* ============================================================
   Reddit — OAuth + recent activity/karma
   ============================================================ */

const reddit = {
  scopes: "identity history read",

  authHeader(cfg) {
    return "Basic " + Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString("base64");
  },

  buildAuthUrl(redirectUri) {
    const cfg = getService("reddit");
    const params = new URLSearchParams({
      client_id: cfg.clientId,
      response_type: "code",
      state: "dashboard",
      redirect_uri: redirectUri,
      duration: "permanent",
      scope: this.scopes,
    });
    return `https://www.reddit.com/api/v1/authorize?${params}`;
  },

  async exchangeCode(code, redirectUri) {
    const cfg = getService("reddit");
    const res = await fetch("https://www.reddit.com/api/v1/access_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: this.authHeader(cfg),
        "User-Agent": cfg.userAgent || "personal-dashboard/1.0",
      },
      body: new URLSearchParams({ grant_type: "authorization_code", code, redirect_uri: redirectUri }),
    });
    const data = await res.json();
    if (data.refresh_token) setService("reddit", { refreshToken: data.refresh_token });
    return data;
  },

  async getAccessToken() {
    const cfg = getService("reddit");
    if (!cfg.refreshToken) return null;
    const res = await fetch("https://www.reddit.com/api/v1/access_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: this.authHeader(cfg),
        "User-Agent": cfg.userAgent || "personal-dashboard/1.0",
      },
      body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: cfg.refreshToken }),
    });
    const data = await res.json();
    return data.access_token || null;
  },

  async getActivity() {
    const cfg = getService("reddit");
    const token = await this.getAccessToken();
    if (!token) return { connected: false };
    const headers = { Authorization: `Bearer ${token}`, "User-Agent": cfg.userAgent || "personal-dashboard/1.0" };

    const [meRes, overviewRes] = await Promise.all([
      fetch("https://oauth.reddit.com/api/v1/me", { headers }),
      fetch(`https://oauth.reddit.com/user/${cfg.username}/overview?limit=5`, { headers }),
    ]);
    if (!meRes.ok) return { connected: true, error: `Reddit API ${meRes.status}` };

    const me = await meRes.json();
    const overview = overviewRes.ok ? await overviewRes.json() : { data: { children: [] } };

    return {
      connected: true,
      username: me.name,
      karma: me.total_karma,
      recent: overview.data.children.slice(0, 5).map((c) => ({
        type: c.kind === "t1" ? "comment" : "post",
        subreddit: c.data.subreddit_name_prefixed,
        title: c.data.link_title || c.data.title,
        permalink: `https://reddit.com${c.data.permalink}`,
      })),
    };
  },
};

/* ============================================================
   YouTube — OAuth + activity feed / subscriber count.
   Note: there's no API for private watch history (Google removed
   that for privacy years ago) — this is the closest real signal.
   ============================================================ */

const youtube = {
  scope: "https://www.googleapis.com/auth/youtube.readonly",

  buildAuthUrl(redirectUri) {
    const cfg = getService("youtube");
    const params = new URLSearchParams({
      client_id: cfg.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: this.scope,
      access_type: "offline",
      prompt: "consent",
    });
    return `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
  },

  async exchangeCode(code, redirectUri) {
    const cfg = getService("youtube");
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: cfg.clientId,
        client_secret: cfg.clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    });
    const data = await res.json();
    if (data.refresh_token) setService("youtube", { refreshToken: data.refresh_token });
    return data;
  },

  async getAccessToken() {
    const cfg = getService("youtube");
    if (!cfg.refreshToken) return null;
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: cfg.clientId,
        client_secret: cfg.clientSecret,
        grant_type: "refresh_token",
        refresh_token: cfg.refreshToken,
      }),
    });
    const data = await res.json();
    return data.access_token || null;
  },

  async getActivity() {
    const token = await this.getAccessToken();
    if (!token) return { connected: false };
    const headers = { Authorization: `Bearer ${token}` };

    const [activityRes, channelRes] = await Promise.all([
      fetch("https://www.googleapis.com/youtube/v3/activities?part=snippet,contentDetails&mine=true&maxResults=5", { headers }),
      fetch("https://www.googleapis.com/youtube/v3/channels?part=statistics&mine=true", { headers }),
    ]);
    if (!activityRes.ok) return { connected: true, error: `YouTube API ${activityRes.status}` };

    const activity = await activityRes.json();
    const channel = channelRes.ok ? await channelRes.json() : null;

    return {
      connected: true,
      subscriberCount: channel?.items?.[0]?.statistics?.subscriberCount ?? null,
      recent: (activity.items || []).map((item) => ({ type: item.snippet.type, title: item.snippet.title })),
    };
  },
};

/* ============================================================
   Express app
   ============================================================ */

const app = express();
app.use(express.json());

// First run with nothing configured lands on the wizard instead of an
// empty dashboard. This route must come before express.static so it
// takes priority over static's automatic "/" -> index.html behavior.
app.get("/", (req, res) => {
  const cfg = loadConfig();
  const nothingConfigured =
    !cfg.spotify?.clientId && !cfg.discord?.botToken && !cfg.reddit?.clientId && !cfg.youtube?.clientId;
  if (nothingConfigured) return res.redirect("/setup");
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.get("/setup", (req, res) => res.sendFile(path.join(__dirname, "public", "setup.html")));

app.use(express.static(path.join(__dirname, "public")));

// ---------- Wizard: save credentials, check status ----------

app.get("/api/setup/status", (req, res) => {
  const cfg = loadConfig();
  res.json({
    spotify: {
      configured: !!(cfg.spotify?.clientId && cfg.spotify?.clientSecret),
      connected: !!cfg.spotify?.refreshToken,
    },
    discord: {
      configured: !!(cfg.discord?.botToken && cfg.discord?.userId && cfg.discord?.guildId),
      connected: !!discordLatest.connected,
    },
    reddit: {
      configured: !!(cfg.reddit?.clientId && cfg.reddit?.clientSecret && cfg.reddit?.username),
      connected: !!cfg.reddit?.refreshToken,
    },
    youtube: {
      configured: !!(cfg.youtube?.clientId && cfg.youtube?.clientSecret),
      connected: !!cfg.youtube?.refreshToken,
    },
  });
});

// Only patches keys that were actually sent, so reopening the wizard to
// change one field never silently blanks out the others.
function patchFrom(body, keys) {
  const patch = {};
  for (const key of keys) if (body[key]) patch[key] = body[key];
  return patch;
}

app.post("/api/setup/spotify", (req, res) => {
  setService("spotify", patchFrom(req.body, ["clientId", "clientSecret"]));
  res.json({ ok: true, redirectUri: `${BASE_URL}/auth/spotify/callback` });
});

app.post("/api/setup/discord", (req, res) => {
  setService("discord", patchFrom(req.body, ["botToken", "userId", "guildId"]));
  startDiscordBot();
  res.json({ ok: true });
});

app.post("/api/setup/reddit", (req, res) => {
  const patch = patchFrom(req.body, ["clientId", "clientSecret", "username"]);
  if (patch.username) patch.userAgent = `personal-dashboard/1.0 by u/${patch.username}`;
  setService("reddit", patch);
  res.json({ ok: true, redirectUri: `${BASE_URL}/auth/reddit/callback` });
});

app.post("/api/setup/youtube", (req, res) => {
  setService("youtube", patchFrom(req.body, ["clientId", "clientSecret"]));
  res.json({ ok: true, redirectUri: `${BASE_URL}/auth/google/callback` });
});

// ---------- OAuth: kicked off from the wizard once creds are saved ----------

app.get("/auth/spotify", (req, res) => res.redirect(spotify.buildAuthUrl(`${BASE_URL}/auth/spotify/callback`)));
app.get("/auth/spotify/callback", async (req, res) => {
  await spotify.exchangeCode(req.query.code, `${BASE_URL}/auth/spotify/callback`);
  res.redirect("/setup?connected=spotify");
});

app.get("/auth/reddit", (req, res) => res.redirect(reddit.buildAuthUrl(`${BASE_URL}/auth/reddit/callback`)));
app.get("/auth/reddit/callback", async (req, res) => {
  await reddit.exchangeCode(req.query.code, `${BASE_URL}/auth/reddit/callback`);
  res.redirect("/setup?connected=reddit");
});

app.get("/auth/google", (req, res) => res.redirect(youtube.buildAuthUrl(`${BASE_URL}/auth/google/callback`)));
app.get("/auth/google/callback", async (req, res) => {
  await youtube.exchangeCode(req.query.code, `${BASE_URL}/auth/google/callback`);
  res.redirect("/setup?connected=youtube");
});

// ---------- Data endpoints the dashboard polls ----------

app.get("/api/now-playing", async (req, res) => {
  const nowPlaying = await spotify.getNowPlaying();
  if (nowPlaying.playing) {
    nowPlaying.lyrics = await getLyrics({
      track: nowPlaying.track,
      artist: nowPlaying.artist,
      album: nowPlaying.album,
      durationMs: nowPlaying.durationMs,
    });
  }
  res.json(nowPlaying);
});

app.get("/api/discord", (req, res) => res.json(discordLatest));
app.get("/api/reddit", async (req, res) => res.json(await reddit.getActivity()));
app.get("/api/youtube", async (req, res) => res.json(await youtube.getActivity()));

// Manual fallback tile — for Amazon Music, Pandora, Snapchat, or anything
// else with no personal API. You just type what you're up to.
app.get("/api/custom", (req, res) => res.json(getService("custom")));
app.post("/api/custom", (req, res) => {
  setService("custom", { text: req.body.text || "" });
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Dashboard running at ${BASE_URL}`);
  console.log(`First run? Setup wizard: ${BASE_URL}/setup`);
  startDiscordBot();
});

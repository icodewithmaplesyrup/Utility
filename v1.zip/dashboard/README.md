# Personal Status Board

A self-hosted dashboard for a spare monitor: Spotify now-playing with live
synced lyrics and cover art, Discord status, Reddit activity, YouTube
activity, plus a manual tile for anything with no personal API. Dark/green
theme throughout.

## Quick start

```bash
npm install
cp .env.example .env
npm start
```

Open `http://localhost:3000` — on first run (nothing configured yet) it
redirects straight into the setup wizard at `/setup`, which walks you
through each service one at a time: paste in credentials, hit **Save &
Connect**, it kicks off that service's OAuth flow, and comes back to the
next step automatically. Everything is saved to a local `config.json` next
to the server — gitignore it, and don't share it, since it holds live
tokens.

You can reopen the wizard any time from the **setup** link in the
dashboard's top bar, e.g. to add a service you skipped or fix a typo'd
credential. Re-saving a field only touches that field — the others are
left alone.

## Per-service setup

The wizard shows these same instructions inline, but for reference:

### Spotify
1. Create an app at https://developer.spotify.com/dashboard
2. Add the redirect URI the wizard shows you (`.../auth/spotify/callback`)
3. Paste the Client ID / Secret into the wizard

Cover art and track info come straight from Spotify's API. Lyrics come from
`lrclib.net`, a free open database built for exactly this — no scraping, no
extra account needed.

### Discord
Reading your *own* live activity legitimately requires a bot, not a
self-bot/user-token hack (that's against Discord's ToS and risks a ban).
1. Create an app + bot at https://discord.com/developers/applications
2. Under **Bot**, enable **Presence Intent** and **Server Members Intent**
3. Invite the bot to a private server that only you are in
4. Turn on Developer Mode in Discord (Settings > Advanced) so you can
   right-click yourself and "Copy User ID", and right-click the server icon
   for "Copy Server ID"
5. Paste the bot token, your user ID, and the server ID into the wizard —
   it (re)connects the bot immediately, no restart needed

### Reddit
1. Create a **web app** at https://www.reddit.com/prefs/apps
2. Add the redirect URI the wizard shows you
3. Paste in the client id/secret and your username

### YouTube
1. Create an OAuth client (type: Web application) at
   https://console.cloud.google.com/apis/credentials
2. Enable the **YouTube Data API v3** for that project
3. Add the redirect URI the wizard shows you

Note: YouTube's API has no way to read private watch history (Google removed
that years ago for privacy). This shows your channel's public activity feed
and subscriber count instead — the closest thing that actually exists.

## Services without a real personal API

The wizard explains this on its own "everything else" step, and I didn't
fake these into the dashboard:

- **Amazon Music** — there is a Web API, but it's a gated partner program
  (manual approval, aimed at hardware/app integrations), not self-serve.
- **Pandora** — no public developer API exists.
- **Snapchat** — Snap Kit only covers login, sharing, and Bitmoji. No
  endpoint for your own activity.
- **Instagram** — the API that used to expose personal accounts (Basic
  Display) was shut down by Meta in December 2024. What's left (Graph API)
  only works for Business/Creator accounts, and only shows your own posts.

For all of these, use the **"also doing"** field at the bottom of the
dashboard — plain text, posts to `/api/custom`, shows up like everything
else.

## Apple Music

Apple's official route (MusicKit) needs a paid Apple Developer account
($99/yr) and a signed JWT. If the dashboard runs on the same Mac as your
Music app, a lighter option is polling it locally via AppleScript instead:

```applescript
tell application "Music"
  if player state is playing then
    {name of current track, artist of current track}
  end if
end tell
```

Ask and I'll wire this in as a proper tile if you want it.

## Email

The dashboard has an Email tile in the layout but it isn't wired to
anything yet — it was added as a placeholder to match the requested layout.
Wiring it up would follow the same pattern as the others (Gmail API +
OAuth); say the word if you want it built out.

## Notes

- `config.json` holds both app credentials and refresh tokens — treat it
  like a secrets file (gitignore it, don't share it).
- The playback control buttons in the "now playing" panel are visual only
  — Spotify's API does support real play/pause/skip control if you want
  those wired up too, it just wasn't part of the original ask.
- Poll intervals are conservative (3s for now-playing, 30s for Reddit/
  YouTube) to stay well inside each API's rate limits. Tune in
  `public/index.html`.
